import time
from redis.cluster import RedisCluster, ClusterNode

SID = "12403030125"
N = 1000 + 100 * 0 + 25
Q = 100

startup_nodes = [
    ClusterNode("127.0.0.1", 30125),
    ClusterNode("127.0.0.1", 30126),
    ClusterNode("127.0.0.1", 30127)
]
rc = RedisCluster(startup_nodes=startup_nodes, decode_responses=True)


print("========4‑1 两种写入方案对比（5分）========")
start_a = time.time()
for i in range(1, N + 1):
    key = f"exam:{SID}:seq:{i}"
    val = f"value-{SID}-{i}"
    rc.set(key, val)
end_a = time.time()
time_a_ms = (end_a - start_a) * 1000

batch_count = (N + Q - 1) // Q
last_batch_size = N % Q
if last_batch_size == 0:
    last_batch_size = Q

start_b = time.time()
for batch_idx in range(batch_count):
    pipe = rc.pipeline(transaction=False)
    begin = batch_idx * Q + 1
    end_idx = min((batch_idx + 1) * Q, N)
    for i in range(begin, end_idx + 1):
        k = f"exam:{SID}:pipe:{i}"
        v = f"value-{SID}-{i}"
        pipe.set(k, v)
    pipe.execute()
end_b = time.time()
time_b_ms = (end_b - start_b) * 1000


print("\n========4‑2 结果输出（5分）========")
print("|指标|数值|")
print("|---|---|")
print(f"|总写入条数|{N}|")
print(f"|Pipeline批次数量|{batch_count}|")
print(f"|最后一批条数|{last_batch_size}|")
print(f"|逐条写入耗时(ms)|{time_a_ms:.2f}|")
print(f"|Pipeline写入耗时(ms)|{time_b_ms:.2f}|")

print("\n问题回答：")
print("Pipeline一般更快，减少多次网络往返RTT。本机虚拟机延迟很低时差距可能不大，甚至循环构造命令带来额外开销。")
print("影响因素：本机低延迟、循环构造命令开销、Redis本身负载。")

