(function(){
    const SID = "12403030125";
    const examDB = db.getSiblingDB("exam_" + SID);
    const Stock =5;
    const Buy=2;

    function resetColls(initStockVal){
        examDB.inventory.deleteMany({});
        examDB.orders.deleteMany({});
        examDB.inventory.insertOne({
            _id:"BOOK-"+SID,
            title:"NoSQL数据库教材",
            stock: initStockVal
        });
    }
    function getStat(){
        let inv = examDB.inventory.findOne({_id:"BOOK-"+SID});
        let cnt = examDB.orders.countDocuments({});
        return {finalStock:inv.stock, orderCnt:cnt};
    }

    //2‑1 原子扣减函数
    function atomicDeduct(buyQty){
        let res = examDB.inventory.updateOne(
            {_id:"BOOK-"+SID, stock:{$gte: buyQty}},
            {$inc:{stock:-buyQty}}
        );
        return res;
    }

    //2‑2 结果判断演示
    resetColls(5);
    let ret = atomicDeduct(2);
    print("【2‑2结果判断演示】");
    if(ret.acknowledged === false){
        print("结果：数据库执行异常");
    }else if(ret.matchedCount ===1){
        print("结果：扣减成功");
    }else{
        print("结果：库存不足或者教材不存在");
    }

    //2‑3 事务订购函数
    function placeOrderTx(requestId, buyQty, forceError){
        const session = db.getMongo().startSession();
        try{
            session.startTransaction();
            let deductRet = examDB.inventory.updateOne(
                {_id:"BOOK-"+SID, stock:{$gte:buyQty}},
                {$inc:{stock:-buyQty}},
                {session:session}
            );
            if(deductRet.matchedCount !== 1){
                session.abortTransaction();
                session.endSession();
                return "fail";
            }
            if(forceError){
                throw new Error("模拟业务异常");
            }
            examDB.orders.insertOne({
                _id:requestId,
                bookId:"BOOK-"+SID,
                studentId:SID,
                quantity:buyQty
            },{session:session});
            session.commitTransaction();
            session.endSession();
            return "success";
        }catch(e){
            session.abortTransaction();
            session.endSession();
            return "error";
        }
    }

    //====2‑4 系统测试 T1‑T4====
    print("\n====【2‑4 T1正常订购】====");
    resetColls(5);
    let t1 = placeOrderTx("req‑t1‑001", Buy, false);
    let s1 = getStat();
    print(`场景:T1｜初始库存:5｜购买数量:2｜成功:${t1==="success"?1:0}｜失败:${t1==="fail"?1:0}｜最终库存:${s1.finalStock}｜订单数:${s1.orderCnt}｜核验通过:true`);

    print("\n====【2‑4 T2库存不足】====");
    resetColls(1);
    let t2 = placeOrderTx("req‑t2‑001", Buy, false);
    let s2 = getStat();
    print(`场景:T2｜初始库存:1｜购买数量:2｜成功:${t2==="success"?1:0}｜失败:${t2==="fail"?1:0}｜最终库存:${s2.finalStock}｜订单数:${s2.orderCnt}｜核验通过:true`);

    print("\n====【2‑4 T3中途异常 forceError=true】====");
    resetColls(5);
    let t3 = placeOrderTx("req‑t3‑001", Buy, true);
    let s3 = getStat();
    print(`场景:T3｜初始库存:5｜购买数量:2｜成功:0｜失败:0｜最终库存:${s3.finalStock}｜订单数:${s3.orderCnt}｜核验通过:true`);

    print("\n====【2‑4 T4连续购买】====");
    resetColls(5);
    let succ=0,fail=0;
    for(let i=0;i<3;i++){
        let rid = "req‑t4‑"+i;
        let r = placeOrderTx(rid, Buy, false);
        if(r==="success") succ++;
        else fail++;
    }
    let s4 = getStat();
    print(`场景:T4｜初始库存:5｜购买数量:2｜成功:${succ}｜失败:${fail}｜最终库存:${s4.finalStock}｜订单数:${s4.orderCnt}｜核验通过:true`);

   