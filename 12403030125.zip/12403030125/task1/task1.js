
const SID = "12403030125";
const examDB = db.getSiblingDB("exam_" + SID);

// ==========初始化数据==========
examDB.courses.deleteMany({});
examDB.courses.insertMany([
  {
    _id: "COURSE-" + SID + "-01",
    title: "NoSQL数据库",
    teacher: "张老师",
    status: "OPEN",
    chapters: [
      { chapterId: "CH01", title: "MongoDB基础", hours: 2 },
      { chapterId: "CH02", title: "Redis基础", hours: 2 }
    ]
  },
  {
    _id: "COURSE-" + SID + "-02",
    title: "数据库原理",
    teacher: "张老师",
    status: "CLOSED",
    chapters: [
      { chapterId: "CH01", title: "关系模型", hours: 2 }
    ]
  },
  {
    _id: "COURSE-" + SID + "-03",
    title: "机器学习",
    teacher: "李老师",
    status: "OPEN",
    chapters: [
      { chapterId: "CH01", title: "分类", hours: 2 },
      { chapterId: "CH02", title: "聚类", hours: 2 }
    ]
  }
]);
print("=======1.查询张老师 OPEN状态课程，带章节数量=======");
let q1 = examDB.courses.find(
  { teacher: "张老师", status: "OPEN" },
  { _id: 1, title: 1, chapterCount: { $size: "$chapters" } }
).toArray();
printjson(q1);

print("\n=======2.局部更新CH02章节标题=======");
let updRet = examDB.courses.updateOne(
  { _id: "COURSE-" + SID + "-01", "chapters.chapterId": "CH02" },
  { $set: { "chapters.$.title": "Redis基础与应用-25" } }
);
printjson(updRet);
let courseDoc = examDB.courses.findOne({ _id: "COURSE-" + SID + "-01" });
printjson(courseDoc);

print("\n=======3.增加CH03章节，连续两次执行=======");
let add1 = examDB.courses.updateOne(
  { _id: "COURSE-" + SID + "-01" },
  { $addToSet: { chapters: { chapterId: "CH03", title: "Redis高级操作", hours: 3 } } }
);
print("第一次新增返回：");
printjson(add1);
let add2 = examDB.courses.updateOne(
  { _id: "COURSE-" + SID + "-01" },
  { $addToSet: { chapters: { chapterId: "CH03", title: "Redis高级操作", hours: 3 } } }
);
print("第二次重复新增返回：");
printjson(add2);

print("\n=======4.验证结果=======");
let c = examDB.courses.findOne({ _id: "COURSE-" + SID + "-01" });
let ch02 = c.chapters.find(x => x.chapterId === "CH02");
let ch03List = c.chapters.filter(x => x.chapterId === "CH03");
print("(1)CH02标题：" + ch02.title);
print("(2)CH03数量：" + ch03List.length);
print("(3)章节总数：" + c.chapters.length);
print("(4)teacher=" + c.teacher + "  status=" + c.status);

print("\n【简答】局部更新优势：");
print("1.替换整个文档需要把完整文档读到客户端修改再写回，并发场景会发生丢失更新；");
print("2.$set/$addToSet是服务端原子局部更新，不需要拉取全部文档；");
print("3.仅修改目标字段，网络传输量小，性能更高；");
print("4.不会因为客户端漏写字段造成原有数据丢失。");
