import time
from redis.cluster import RedisCluster, ClusterNode

SID = "12403030125"
prefix = f"exam:{SID}:"

startup_nodes = [
    ClusterNode("127.0.0.1", 30125),
    ClusterNode("127.0.0.1", 30126),
    ClusterNode("127.0.0.1", 30127)
]
rc = RedisCluster(startup_nodes=startup_nodes, decode_responses=True)


print("========3‑1 学生信息维护 Hash（6分）========")
hash_key = prefix + "student:info"
rc.delete(hash_key)
rc.hset(hash_key, mapping={
    "studentId": SID,
    "name": "张三",
    "className": "计科2班",
    "courseId": f"COURSE-{SID}-01",
    "status": "learning"
})
rc.hset(hash_key, "status", "completed")
res_name_status = rc.hmget(hash_key, ["name", "status"])
print("单独读取name、status：", res_name_status)
full_hash = rc.hgetall(hash_key)
print("Hash全部内容：", full_hash)


print("\n========3‑2 已完成章节 Set（6分）========")
set_key = prefix + "finished:chapters"
rc.delete(set_key)
step_list = ["CH01", "CH02", "CH02", "CH03"]
for item in step_list:
    rc.sadd(set_key, item)
    cnt = rc.scard(set_key)
    print(f"提交 {item}，当前已完成数量：{cnt}")

all_members = rc.smembers(set_key)
print("全部已完成章节：", all_members)
print("CH02 是否存在：", rc.sismember(set_key, "CH02"))
print("CH04 是否存在：", rc.sismember(set_key, "CH04"))


print("\n========3‑3 排行榜 Sorted‑Set（6分）========")
zset_key = prefix + "score:rank"
rc.delete(zset_key)
rc.zadd(zset_key, {
    f"Student:{SID}": 70,
    "demo:01": 85,
    "demo:02": 90,
    "demo:03": 60,
    "demo:04": 80
})

top3_before = rc.zrange(zset_key, 0, 2, desc=True, withscores=True)
print("加分前前三名：", top3_before)
rc.zincrby(zset_key, 20, f"Student:{SID}")
top3_after = rc.zrange(zset_key, 0, 2, desc=True, withscores=True)
print("加分后前三名：", top3_after)
my_score = rc.zscore(zset_key, f"Student:{SID}")
rank_index = rc.zrevrank(zset_key, f"Student:{SID}")
rank_str = f"第{rank_index + 1}名"
print(f"本人分数：{my_score}，排名：{rank_str}")


print("\n========3‑4 会话过期 String（6分）========")
ses_key = prefix + "session"
rc.set(ses_key, "session-token-2026-abc", ex=5)
val = rc.get(ses_key)
ttl_first = rc.ttl(ses_key)
print(f"创建会话，值={val}，剩余TTL={ttl_first}")
print("等待6秒……")
time.sleep(6)
exist_flag = rc.exists(ses_key)
ttl_after = rc.ttl(ses_key)
print(f"等待后，键是否存在:{exist_flag}, TTL={ttl_after}")
if exist_flag == 0:
    print("过期验证：通过")
else:
    print("过期验证：不通过")


print("\n========3‑5 类型核验（6分）========")
rc.set(ses_key, "tmp-check-type", ex=10)
t_hash = rc.type(hash_key)
t_set = rc.type(set_key)
t_zset = rc.type(zset_key)
t_string = rc.type(ses_key)

print(f"Hash类型：{t_hash}")
print(f"Set类型：{t_set}")
print(f"ZSet类型：{t_zset}")
print(f"String类型：{t_string}")

print("\n数据类型选择说明：")
print("Hash：存储对象信息，可以单独读写字段，适合学生信息。")
print("Set：自动去重，适合记录完成的章节。")
print("Sorted Set：自带分数排序，适合排行榜。")
print("String：简单K-V，支持TTL过期，适合会话。")
